package a3;

import javax.swing.*;
import java.awt.*;

public class Telaadminlogin extends JFrame {
    private JTextField emailField;
    private JPasswordField senhaField;

    private static final String EMAIL_ADMIN = "admin@saojudas.com";
    private static final String SENHA_ADMIN = "12345678";

    public Telaadminlogin() {
        AppTheme.configureFrame(this, "Login administrador");

        JPanel root = AppTheme.root(0, "Administrador", "Acesso restrito para exportar o dashboard das avaliações.");
        JPanel card = AppTheme.card();
        GridBagConstraints gbc;

        JLabel title = AppTheme.title("Área do administrador");
        title.setHorizontalAlignment(SwingConstants.CENTER);
        gbc = AppTheme.gbc(0, 0);
        gbc.gridwidth = 2;
        card.add(title, gbc);

        JLabel subtitle = AppTheme.subtitle("Entre com o email e senha do administrador. Usuário comum não precisa passar por essa tela.");
        subtitle.setHorizontalAlignment(SwingConstants.CENTER);
        gbc = AppTheme.gbc(0, 1);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 8, 20, 8);
        card.add(subtitle, gbc);

        gbc = AppTheme.gbc(0, 2);
        gbc.gridwidth = 1;
        card.add(AppTheme.label("Email"), gbc);
        emailField = AppTheme.textField("admin@saojudas.com");
        gbc = AppTheme.gbc(1, 2);
        gbc.weightx = 3;
        card.add(emailField, gbc);

        gbc = AppTheme.gbc(0, 3);
        gbc.weightx = 1;
        card.add(AppTheme.label("Senha"), gbc);
        senhaField = AppTheme.passwordField("Senha do administrador");
        gbc = AppTheme.gbc(1, 3);
        gbc.weightx = 3;
        card.add(senhaField, gbc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttons.setOpaque(false);
        JButton voltar = AppTheme.secondaryButton("Voltar");
        voltar.addActionListener(e -> { new Tela_1().setVisible(true); dispose(); });
        JButton entrar = AppTheme.primaryButton("Entrar");
        entrar.addActionListener(e -> validarLogin());
        senhaField.addActionListener(e -> validarLogin());

        buttons.add(voltar);
        buttons.add(entrar);

        gbc = AppTheme.gbc(0, 4);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(24, 8, 8, 8);
        card.add(buttons, gbc);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void validarLogin() {
        String email = emailField.getText() == null ? "" : emailField.getText().trim();
        String senha = new String(senhaField.getPassword());

        if (EMAIL_ADMIN.equalsIgnoreCase(email) && SENHA_ADMIN.equals(senha)) {
            new Telaadmin().setVisible(true);
            dispose();
            return;
        }

        JOptionPane.showMessageDialog(
                this,
                "Email ou senha de administrador inválidos.",
                "Acesso negado",
                JOptionPane.ERROR_MESSAGE
        );
        senhaField.setText("");
        senhaField.requestFocus();
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Telaadminlogin().setVisible(true));
    }
}
