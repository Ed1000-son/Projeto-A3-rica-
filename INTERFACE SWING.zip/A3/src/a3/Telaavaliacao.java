package a3;

import javax.swing.*;
import java.awt.*;
import java.util.Hashtable;

public class Telaavaliacao extends JFrame {
    private JSlider esperaSlider;
    private JSlider lotacaoSlider;
    private JSlider qualidadeSlider;

    public Telaavaliacao() {
        AppTheme.configureFrame(this, "Avaliação - Pesquisa de Satisfação");

        JPanel root = AppTheme.root(6, "Avaliação", "Dê notas de 0 a 5 para os principais pontos da experiência.");
        JPanel card = AppTheme.card();
        GridBagConstraints gbc;

        JLabel title = AppTheme.title("Como foi sua experiência?");
        gbc = AppTheme.gbc(0, 0);
        gbc.gridwidth = 2;
        card.add(title, gbc);

        JLabel subtitle = AppTheme.subtitle("0 significa muito ruim e 5 significa excelente. Seja sincero: nota alta sem motivo não ajuda a melhorar nada.");
        gbc = AppTheme.gbc(0, 1);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 8, 20, 8);
        card.add(subtitle, gbc);

        esperaSlider = addSlider(card, 2, "Tempo de espera");
        lotacaoSlider = addSlider(card, 3, "Lotação do transporte");
        qualidadeSlider = addSlider(card, 4, "Qualidade geral do serviço");

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttons.setOpaque(false);
        JButton back = AppTheme.secondaryButton("Voltar");
        back.addActionListener(e -> { new Teladata().setVisible(true); dispose(); });
        JButton next = AppTheme.primaryButton("Finalizar avaliação");
        next.addActionListener(e -> continuar());
        buttons.add(back);
        buttons.add(next);

        gbc = AppTheme.gbc(0, 5);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(24, 8, 8, 8);
        card.add(buttons, gbc);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JSlider addSlider(JPanel card, int row, String labelText) {
        GridBagConstraints gbc = AppTheme.gbc(0, row);
        gbc.gridwidth = 1;
        gbc.weightx = 1;
        card.add(AppTheme.label(labelText), gbc);

        JSlider slider = new JSlider(0, 5, 3);
        slider.setMajorTickSpacing(1);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setSnapToTicks(true);
        slider.setBackground(AppTheme.CARD);
        slider.setForeground(AppTheme.TEXT);
        slider.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        Hashtable<Integer, JLabel> labels = new Hashtable<>();
        for (int i = 0; i <= 5; i++) labels.put(i, new JLabel(String.valueOf(i)));
        slider.setLabelTable(labels);

        gbc = AppTheme.gbc(1, row);
        gbc.weightx = 3;
        card.add(slider, gbc);
        return slider;
    }

    private void continuar() {
        AppState.espera = esperaSlider.getValue();
        AppState.lotacao = lotacaoSlider.getValue();
        AppState.qualidade = qualidadeSlider.getValue();
        new Tela_2().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Telaavaliacao().setVisible(true));
    }
}
