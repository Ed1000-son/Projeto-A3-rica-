package a3;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;

public class Telaintervalo extends JFrame {
    private JTextField intervaloField;

    public Telaintervalo() {
        AppTheme.configureFrame(this, "Intervalo médio - Pesquisa de Satisfação");

        JPanel root = AppTheme.root(4, "Intervalo médio", "Informe em minutos quanto tempo o transporte demora para passar.");
        JPanel card = AppTheme.card();
        GridBagConstraints gbc;

        JLabel title = AppTheme.title("Tempo de espera / intervalo");
        gbc = AppTheme.gbc(0, 0);
        gbc.gridwidth = 2;
        card.add(title, gbc);

        JLabel subtitle = AppTheme.subtitle("Digite apenas números. Esse valor será salvo como minutos no banco de dados.");
        gbc = AppTheme.gbc(0, 1);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 8, 20, 8);
        card.add(subtitle, gbc);

        gbc = AppTheme.gbc(0, 2);
        gbc.gridwidth = 1;
        card.add(AppTheme.label("Transporte"), gbc);
        JLabel transporteLabel = valor(AppState.tipoTransporte);
        gbc = AppTheme.gbc(1, 2);
        gbc.weightx = 3;
        card.add(transporteLabel, gbc);

        gbc = AppTheme.gbc(0, 3);
        gbc.weightx = 1;
        card.add(AppTheme.label("Linha"), gbc);
        JLabel linhaLabel = valor(AppState.linha);
        gbc = AppTheme.gbc(1, 3);
        gbc.weightx = 3;
        card.add(linhaLabel, gbc);

        gbc = AppTheme.gbc(0, 4);
        gbc.weightx = 1;
        card.add(AppTheme.label("Estação"), gbc);
        JLabel estacaoLabel = valor(AppState.estacao);
        gbc = AppTheme.gbc(1, 4);
        gbc.weightx = 3;
        card.add(estacaoLabel, gbc);

        gbc = AppTheme.gbc(0, 5);
        gbc.weightx = 1;
        card.add(AppTheme.label("Tempo em minutos"), gbc);
        intervaloField = AppTheme.textField("Exemplo: 8");
        aplicarFiltroNumerico(intervaloField);
        if (AppState.intervaloMedioMinutos > 0) {
            intervaloField.setText(String.valueOf(AppState.intervaloMedioMinutos));
        }
        gbc = AppTheme.gbc(1, 5);
        gbc.weightx = 3;
        card.add(intervaloField, gbc);

        JLabel dica = AppTheme.subtitle("Exemplo: se o trem demora cerca de 10 minutos para passar, digite 10.");
        gbc = AppTheme.gbc(1, 6);
        gbc.insets = new Insets(0, 8, 12, 8);
        card.add(dica, gbc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttons.setOpaque(false);
        JButton back = AppTheme.secondaryButton("Voltar");
        back.addActionListener(e -> { new Telalocal().setVisible(true); dispose(); });
        JButton next = AppTheme.primaryButton("Continuar");
        next.addActionListener(e -> continuar());
        buttons.add(back);
        buttons.add(next);

        gbc = AppTheme.gbc(0, 7);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(24, 8, 8, 8);
        card.add(buttons, gbc);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JLabel valor(String texto) {
        JLabel label = new JLabel(texto == null || texto.isBlank() ? "-" : texto);
        label.putClientProperty("themeRole", "text");
        label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        label.setForeground(AppTheme.TEXT);
        return label;
    }

    private void aplicarFiltroNumerico(JTextField field) {
        ((AbstractDocument) field.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string != null && string.matches("\\d+")) {
                    super.insertString(fb, offset, string, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text == null || text.isEmpty() || text.matches("\\d+")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

    private void continuar() {
        String texto = intervaloField.getText().trim();

        if (texto.isEmpty()) {
            AppTheme.showError(this, "Informe o tempo em minutos.");
            intervaloField.requestFocus();
            return;
        }

        int minutos;
        try {
            minutos = Integer.parseInt(texto);
        } catch (NumberFormatException e) {
            AppTheme.showError(this, "Digite apenas números no tempo em minutos.");
            intervaloField.requestFocus();
            return;
        }

        if (minutos <= 0) {
            AppTheme.showError(this, "O tempo precisa ser maior que zero.");
            intervaloField.requestFocus();
            return;
        }

        AppState.intervaloMedioMinutos = minutos;
        new Teladata().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Telaintervalo().setVisible(true));
    }
}
