package a3;

import javax.swing.*;
import java.awt.*;

public class Telalogin extends JFrame {
    private JTextField nomeField;
    private JTextField cpfField;

    public Telalogin() {
        AppTheme.configureFrame(this, "Cadastro - Pesquisa de Satisfação");

        JPanel root = AppTheme.root(2, "Cadastro", "Informe seus dados para iniciar o registro da avaliação.");
        JPanel card = AppTheme.card();
        GridBagConstraints gbc;

        JLabel title = AppTheme.title("Dados do passageiro");
        gbc = AppTheme.gbc(0, 0);
        gbc.gridwidth = 2;
        card.add(title, gbc);

        JLabel subtitle = AppTheme.subtitle("Preencha nome e CPF. O CPF aceita somente números.");
        gbc = AppTheme.gbc(0, 1);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 8, 20, 8);
        card.add(subtitle, gbc);

        gbc = AppTheme.gbc(0, 2);
        gbc.gridwidth = 1;
        card.add(AppTheme.label("Nome"), gbc);

        nomeField = AppTheme.textField("Digite seu nome completo");
        gbc = AppTheme.gbc(1, 2);
        gbc.weightx = 3;
        card.add(nomeField, gbc);

        gbc = AppTheme.gbc(0, 3);
        gbc.weightx = 1;
        card.add(AppTheme.label("CPF"), gbc);

        cpfField = AppTheme.textField("Somente números");
        cpfField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isDigit(c) || cpfField.getText().length() >= 11) evt.consume();
            }
        });
        gbc = AppTheme.gbc(1, 3);
        gbc.weightx = 3;
        card.add(cpfField, gbc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttons.setOpaque(false);
        JButton back = AppTheme.secondaryButton("Voltar");
        back.addActionListener(e -> { new Tela_1().setVisible(true); dispose(); });
        JButton next = AppTheme.primaryButton("Continuar");
        next.addActionListener(e -> continuar());
        buttons.add(back);
        buttons.add(next);

        gbc = AppTheme.gbc(0, 4);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(24, 8, 8, 8);
        card.add(buttons, gbc);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void continuar() {
        String nome = nomeField.getText().trim();
        String cpf = cpfField.getText().trim();
        if (nome.length() < 3) {
            AppTheme.showError(this, "Informe um nome válido.");
            return;
        }
        if (cpf.length() != 11) {
            AppTheme.showError(this, "Informe um CPF com 11 números.");
            return;
        }
        AppState.nome = nome;
        AppState.cpf = cpf;
        new Telalocal().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Telalogin().setVisible(true));
    }
}
