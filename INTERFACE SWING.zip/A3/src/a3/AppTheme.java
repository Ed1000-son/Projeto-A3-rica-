package a3;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public final class AppTheme {
    public static Color BG = new Color(243, 246, 251);
    public static Color CARD = Color.WHITE;
    public static Color PRIMARY = new Color(25, 86, 166);
    public static Color PRIMARY_DARK = new Color(15, 57, 116);
    public static Color TEXT = new Color(30, 41, 59);
    public static Color MUTED = new Color(100, 116, 139);
    public static Color BORDER = new Color(148, 163, 184);
    public static Color FIELD_BG = Color.WHITE;
    public static Color FIELD_TEXT = Color.BLACK;
    public static Color SUCCESS = new Color(22, 163, 74);

    private static boolean darkMode = false;

    private AppTheme() {}

    public static void setupLookAndFeel() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}
        applyPalette(false);
    }

    private static void applyPalette(boolean dark) {
        darkMode = dark;
        if (dark) {
            BG = new Color(15, 23, 42);
            CARD = new Color(30, 41, 59);
            PRIMARY = new Color(96, 165, 250);
            PRIMARY_DARK = new Color(59, 130, 246);
            TEXT = new Color(241, 245, 249);
            MUTED = new Color(203, 213, 225);
            BORDER = new Color(71, 85, 105);
            // Campos de entrada ficam sempre claros para evitar texto branco sumindo no modo escuro.
            FIELD_BG = Color.WHITE;
            FIELD_TEXT = Color.BLACK;
            SUCCESS = new Color(74, 222, 128);
        } else {
            BG = new Color(243, 246, 251);
            CARD = Color.WHITE;
            PRIMARY = new Color(25, 86, 166);
            PRIMARY_DARK = new Color(15, 57, 116);
            TEXT = new Color(30, 41, 59);
            MUTED = new Color(100, 116, 139);
            BORDER = new Color(148, 163, 184);
            FIELD_BG = Color.WHITE;
            FIELD_TEXT = Color.BLACK;
            SUCCESS = new Color(22, 163, 74);
        }

        UIManager.put("control", BG);
        UIManager.put("nimbusBase", PRIMARY);
        UIManager.put("nimbusFocus", PRIMARY_DARK);
        UIManager.put("text", TEXT);
        UIManager.put("TextField.background", FIELD_BG);
        UIManager.put("TextField.foreground", FIELD_TEXT);
        UIManager.put("ComboBox.background", FIELD_BG);
        UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("TextArea.background", FIELD_BG);
        UIManager.put("TextArea.foreground", FIELD_TEXT);
    }

    public static void configureFrame(JFrame frame, String title) {
        frame.setTitle(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(820, 560));
        frame.setSize(980, 640);
        frame.setLocationRelativeTo(null);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.getContentPane().setBackground(BG);
    }

    public static JPanel root(int step, String title, String subtitle) {
        JPanel root = new JPanel(new BorderLayout(0, 20));
        root.putClientProperty("themeRole", "root");
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(24, 28, 24, 28));

        JPanel header = new JPanel(new BorderLayout(16, 6));
        header.putClientProperty("themeRole", "transparent");
        header.setOpaque(false);

        JLabel brand = new JLabel("Pesquisa de Satisfação - Transporte Público");
        brand.putClientProperty("themeRole", "text");
        brand.setFont(new Font("Segoe UI", Font.BOLD, 20));
        brand.setForeground(TEXT);

        JLabel desc = new JLabel(subtitle);
        desc.putClientProperty("themeRole", "muted");
        desc.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        desc.setForeground(MUTED);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.putClientProperty("themeRole", "transparent");
        right.setOpaque(false);

        JLabel sub = new JLabel("Etapa " + step + " de 7");
        sub.putClientProperty("themeRole", "primaryText");
        sub.setFont(new Font("Segoe UI", Font.BOLD, 13));
        sub.setForeground(PRIMARY);

        JButton theme = secondaryButton(darkMode ? "☀ Tema claro" : "🌙 Tema escuro");
        theme.setToolTipText("Alternar tema claro/escuro");
        theme.addActionListener(e -> {
            applyPalette(!darkMode);
            Window w = SwingUtilities.getWindowAncestor(root);
            if (w instanceof JFrame frame) {
                applyTheme(frame.getContentPane());
                frame.repaint();
            }
        });

        right.add(sub);
        right.add(theme);

        header.add(brand, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        header.add(desc, BorderLayout.SOUTH);

        root.add(header, BorderLayout.NORTH);
        return root;
    }

    public static JPanel card() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.putClientProperty("themeRole", "card");
        panel.setBackground(CARD);
        panel.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(BORDER, 18, 1),
                new EmptyBorder(30, 34, 30, 34)
        ));
        return panel;
    }

    public static JLabel title(String text) {
        JLabel label = new JLabel(text);
        label.putClientProperty("themeRole", "text");
        label.setFont(new Font("Segoe UI", Font.BOLD, 30));
        label.setForeground(TEXT);
        return label;
    }

    public static JLabel subtitle(String text) {
        JLabel label = new JLabel("<html><div style='width:650px;'>" + text + "</div></html>");
        label.putClientProperty("themeRole", "muted");
        label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        label.setForeground(MUTED);
        return label;
    }

    public static JLabel label(String text) {
        JLabel label = new JLabel(text);
        label.putClientProperty("themeRole", "text");
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(TEXT);
        return label;
    }

    public static JButton primaryButton(String text) {
        JButton btn = new JButton(text);
        btn.putClientProperty("themeRole", "primaryButton");
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setBackground(PRIMARY);
        btn.setForeground(darkMode ? new Color(15, 23, 42) : Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(12, 24, 12, 24));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(PRIMARY_DARK); }
            public void mouseExited(MouseEvent e) { btn.setBackground(PRIMARY); }
        });
        return btn;
    }

    public static JButton secondaryButton(String text) {
        JButton btn = new JButton(text);
        btn.putClientProperty("themeRole", "secondaryButton");
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBackground(CARD);
        btn.setForeground(PRIMARY);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(BORDER, 12, 1),
                new EmptyBorder(10, 18, 10, 18)
        ));
        return btn;
    }

    public static JTextField textField(String placeholder) {
        JTextField field = new JTextField();
        field.putClientProperty("themeRole", "field");
        field.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        field.setForeground(FIELD_TEXT);
        field.setBackground(FIELD_BG);
        field.setCaretColor(FIELD_TEXT);
        field.setToolTipText(placeholder);
        field.setBorder(fieldBorder(false));
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) { field.setBorder(fieldBorder(true)); }
            public void focusLost(FocusEvent e) { field.setBorder(fieldBorder(false)); }
        });
        return field;
    }

    public static JPasswordField passwordField(String placeholder) {
        JPasswordField field = new JPasswordField();
        field.putClientProperty("themeRole", "field");
        field.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        field.setForeground(FIELD_TEXT);
        field.setBackground(FIELD_BG);
        field.setCaretColor(FIELD_TEXT);
        field.setToolTipText(placeholder);
        field.setBorder(fieldBorder(false));
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) { field.setBorder(fieldBorder(true)); }
            public void focusLost(FocusEvent e) { field.setBorder(fieldBorder(false)); }
        });
        return field;
    }

    public static JTextArea textArea() {
        JTextArea area = new JTextArea(5, 20);
        area.putClientProperty("themeRole", "field");
        area.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setForeground(FIELD_TEXT);
        area.setBackground(FIELD_BG);
        area.setCaretColor(FIELD_TEXT);
        area.setBorder(fieldBorder(false));
        area.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) { area.setBorder(fieldBorder(true)); }
            public void focusLost(FocusEvent e) { area.setBorder(fieldBorder(false)); }
        });
        return area;
    }

    public static JComboBox<String> combo(String[] values) {
        JComboBox<String> cb = new JComboBox<>(values);
        cb.putClientProperty("themeRole", "field");
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        cb.setBackground(FIELD_BG);
        cb.setForeground(TEXT);
        cb.setBorder(fieldBorder(false));
        cb.setUI(new BasicComboBoxUI());
        cb.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) { cb.setBorder(fieldBorder(true)); }
            public void focusLost(FocusEvent e) { cb.setBorder(fieldBorder(false)); }
        });
        return cb;
    }

    public static void configureTable(JTable table) {
        table.putClientProperty("themeRole", "dataTable");
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(28);
        table.setBackground(Color.WHITE);
        table.setForeground(Color.BLACK);
        table.setGridColor(new Color(220, 220, 220));
        table.setSelectionBackground(new Color(220, 235, 255));
        table.setSelectionForeground(Color.BLACK);
        table.setOpaque(true);

        JTableHeader header = table.getTableHeader();
        if (header != null) {
            header.putClientProperty("themeRole", "dataTableHeader");
            header.setFont(new Font("Segoe UI", Font.BOLD, 14));
            header.setBackground(Color.WHITE);
            header.setForeground(Color.BLACK);
            header.setOpaque(true);
        }
    }

    private static javax.swing.border.Border fieldBorder(boolean focused) {
        Color color = focused ? PRIMARY : BORDER;
        int thickness = focused ? 2 : 1;
        return BorderFactory.createCompoundBorder(
                new RoundedBorder(color, 12, thickness),
                new EmptyBorder(11, 14, 11, 14)
        );
    }

    public static GridBagConstraints gbc(int x, int y) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        return gbc;
    }

    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Atenção", JOptionPane.WARNING_MESSAGE);
    }

    private static void applyTheme(Component component) {
        Object role = null;
        if (component instanceof JComponent jc) {
            role = jc.getClientProperty("themeRole");
        }

        if (component instanceof JFrame frame) {
            frame.getContentPane().setBackground(BG);
        } else if (component instanceof JPanel panel) {
            if ("card".equals(role)) {
                panel.setBackground(CARD);
                panel.setBorder(BorderFactory.createCompoundBorder(
                        new RoundedBorder(BORDER, 18, 1),
                        new EmptyBorder(30, 34, 30, 34)
                ));
            } else if ("root".equals(role)) {
                panel.setBackground(BG);
            } else {
                panel.setOpaque(false);
            }
        } else if (component instanceof JLabel label) {
            if ("muted".equals(role)) label.setForeground(MUTED);
            else if ("primaryText".equals(role)) label.setForeground(PRIMARY);
            else label.setForeground(TEXT);
        } else if (component instanceof JButton button) {
            if ("primaryButton".equals(role)) {
                button.setBackground(PRIMARY);
                button.setForeground(darkMode ? new Color(15, 23, 42) : Color.WHITE);
            } else if ("secondaryButton".equals(role)) {
                if (button.getText().contains("Tema")) button.setText(darkMode ? "☀ Tema claro" : "🌙 Tema escuro");
                button.setBackground(CARD);
                button.setForeground(PRIMARY);
                button.setBorder(BorderFactory.createCompoundBorder(
                        new RoundedBorder(BORDER, 12, 1),
                        new EmptyBorder(10, 18, 10, 18)
                ));
            }
        } else if (component instanceof JTextField field) {
            field.setBackground(FIELD_BG);
            field.setForeground(FIELD_TEXT);
            field.setCaretColor(FIELD_TEXT);
            field.setBorder(fieldBorder(field.hasFocus()));
        } else if (component instanceof JTextArea area) {
            area.setBackground(FIELD_BG);
            area.setForeground(FIELD_TEXT);
            area.setCaretColor(FIELD_TEXT);
            area.setBorder(fieldBorder(area.hasFocus()));
        } else if (component instanceof JComboBox<?> cb) {
            cb.setBackground(FIELD_BG);
            cb.setForeground(TEXT);
            cb.setBorder(fieldBorder(cb.hasFocus()));
        } else if (component instanceof JTable table) {
            configureTable(table);
        } else if (component instanceof JTableHeader header) {
            header.setBackground(Color.WHITE);
            header.setForeground(Color.BLACK);
            header.setOpaque(true);
        } else if (component instanceof JScrollPane scroll) {
            scroll.setBackground(CARD);
            if (scroll.getViewport() != null) {
                scroll.getViewport().setBackground(Color.WHITE);
                Component view = scroll.getViewport().getView();
                if (view instanceof JTable table) {
                    configureTable(table);
                }
            }
            scroll.setBorder(fieldBorder(false));
        }

        if (component instanceof Container container) {
            for (Component child : container.getComponents()) {
                applyTheme(child);
            }
        }
    }

    private static class RoundedBorder extends AbstractBorder {
        private final Color color;
        private final int radius;
        private final int thickness;

        RoundedBorder(Color color, int radius, int thickness) {
            this.color = color;
            this.radius = radius;
            this.thickness = thickness;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(thickness));
            g2.drawRoundRect(x + thickness / 2, y + thickness / 2,
                    width - thickness, height - thickness, radius, radius);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(thickness, thickness, thickness, thickness);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = insets.right = insets.top = insets.bottom = thickness;
            return insets;
        }
    }
}
