package a3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class Telaconsulta extends JFrame {
    private DefaultTableModel modelo;
    private JLabel resumoLabel;

    public Telaconsulta() {
        AppTheme.configureFrame(this, "Consulta rápida - Intervalo do trem");

        JPanel root = AppTheme.root(0, "Consulta rápida", "Veja a média de intervalo dos trens com base nas avaliações registradas.");
        JPanel card = AppTheme.card();
        card.setLayout(new BorderLayout(14, 14));

        JPanel topo = new JPanel(new BorderLayout(10, 8));
        topo.setOpaque(false);

        JLabel title = AppTheme.title("Tempo médio do trem");
        JLabel subtitle = AppTheme.subtitle("Essa consulta não pede cadastro. Ela usa as avaliações salvas no banco e calcula a média do campo tempo em minutos.");
        resumoLabel = AppTheme.label("Carregando dados...");

        topo.add(title, BorderLayout.NORTH);
        topo.add(subtitle, BorderLayout.CENTER);
        topo.add(resumoLabel, BorderLayout.SOUTH);

        modelo = new DefaultTableModel(new Object[]{
                "Transporte", "Linha", "Estação", "Média intervalo", "Avaliações", "Última avaliação"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable tabela = new JTable(modelo);
        AppTheme.configureTable(tabela);
        JScrollPane scroll = new JScrollPane(tabela);
        scroll.getViewport().setBackground(Color.WHITE);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        botoes.setOpaque(false);

        JButton voltar = AppTheme.secondaryButton("Voltar");
        voltar.addActionListener(e -> { new Tela_1().setVisible(true); dispose(); });

        JButton atualizar = AppTheme.secondaryButton("Atualizar consulta");
        atualizar.addActionListener(e -> carregarDados());

        botoes.add(voltar);
        botoes.add(atualizar);

        card.add(topo, BorderLayout.NORTH);
        card.add(scroll, BorderLayout.CENTER);
        card.add(botoes, BorderLayout.SOUTH);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
        carregarDados();
    }

    private void carregarDados() {
        modelo.setRowCount(0);
        try {
            List<AvaliacaoDAO.ConsultaIntervalo> dados = AvaliacaoDAO.consultarIntervaloTremUltimaHora();
            if (dados.isEmpty()) {
                resumoLabel.setText("Nenhuma avaliação de trem encontrada no banco. Faça pelo menos uma avaliação de Trem e salve antes de consultar.");
                return;
            }

            int totalAvaliacoes = 0;
            double somaPonderada = 0;
            for (AvaliacaoDAO.ConsultaIntervalo r : dados) {
                totalAvaliacoes += r.quantidadeAvaliacoes;
                somaPonderada += r.mediaIntervalo * r.quantidadeAvaliacoes;
                modelo.addRow(new Object[]{
                        r.tipoTransporte,
                        r.linha,
                        r.estacao,
                        AvaliacaoDAO.formatarDecimal(r.mediaIntervalo) + " min",
                        r.quantidadeAvaliacoes,
                        r.ultimaAvaliacao
                });
            }

            double mediaGeral = somaPonderada / totalAvaliacoes;
            resumoLabel.setText("Média geral dos dados encontrados: " + AvaliacaoDAO.formatarDecimal(mediaGeral) + " minutos | Avaliações usadas: " + totalAvaliacoes);
        } catch (SQLException e) {
            resumoLabel.setText("Erro ao consultar o banco.");
            JOptionPane.showMessageDialog(
                    this,
                    "Não foi possível consultar o banco de dados.\n\n" +
                    "Confira se o MySQL está aberto, se o banco a3_transporte existe, se a tabela avaliacoes foi criada e se o Connector/J está no Classpath.\n\n" +
                    "Erro técnico: " + e.getMessage(),
                    "Erro na consulta",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Telaconsulta().setVisible(true));
    }
}
