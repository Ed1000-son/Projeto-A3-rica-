package a3;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Teladata extends JFrame {
    private JTextField dataField;
    private JTextField horaField;

    public Teladata() {
        AppTheme.configureFrame(this, "Data e hora - Pesquisa de Satisfação");

        JPanel root = AppTheme.root(5, "Data e hora", "Informe quando a viagem aconteceu.");
        JPanel card = AppTheme.card();
        GridBagConstraints gbc;

        JLabel title = AppTheme.title("Quando foi sua viagem?");
        gbc = AppTheme.gbc(0, 0);
        gbc.gridwidth = 2;
        card.add(title, gbc);

        JLabel subtitle = AppTheme.subtitle("Use o formato dd/mm/aaaa para data e hh:mm para hora. Para facilitar, os campos já vêm preenchidos com o momento atual.");
        gbc = AppTheme.gbc(0, 1);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 8, 20, 8);
        card.add(subtitle, gbc);

        gbc = AppTheme.gbc(0, 2);
        gbc.gridwidth = 1;
        card.add(AppTheme.label("Data"), gbc);
        dataField = AppTheme.textField("dd/mm/aaaa");
        dataField.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        gbc = AppTheme.gbc(1, 2);
        gbc.weightx = 3;
        card.add(dataField, gbc);

        gbc = AppTheme.gbc(0, 3);
        gbc.weightx = 1;
        card.add(AppTheme.label("Hora"), gbc);
        horaField = AppTheme.textField("hh:mm");
        horaField.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
        gbc = AppTheme.gbc(1, 3);
        gbc.weightx = 3;
        card.add(horaField, gbc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttons.setOpaque(false);
        JButton back = AppTheme.secondaryButton("Voltar");
        back.addActionListener(e -> { new Telaintervalo().setVisible(true); dispose(); });
        JButton next = AppTheme.primaryButton("Continuar");
        next.addActionListener(e -> continuar());
        buttons.add(back);
        buttons.add(next);

        gbc = AppTheme.gbc(0, 4);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(24, 8, 8, 8);
        card.add(buttons, gbc);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void continuar() {
        String data = dataField.getText().trim();
        String hora = horaField.getText().trim();
        if (!data.matches("\\d{2}/\\d{2}/\\d{4}")) {
            AppTheme.showError(this, "Informe a data no formato dd/mm/aaaa.");
            return;
        }
        if (!hora.matches("\\d{2}:\\d{2}")) {
            AppTheme.showError(this, "Informe a hora no formato hh:mm.");
            return;
        }
        AppState.data = data;
        AppState.hora = hora;
        new Telaavaliacao().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Teladata().setVisible(true));
    }
}
