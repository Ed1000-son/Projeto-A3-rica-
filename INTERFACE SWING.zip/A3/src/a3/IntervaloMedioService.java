package a3;

public final class IntervaloMedioService {

    private IntervaloMedioService() {}

    public static int calcularMinutos(String tipoTransporte, String linha) {
        if (tipoTransporte == null || linha == null) {
            return 0;
        }

        String tipo = tipoTransporte.trim();
        String linhaNormalizada = linha.trim();

        if (tipo.equalsIgnoreCase("Metrô")) {
            if (linhaNormalizada.contains("Linha 15") || linhaNormalizada.contains("Linha 17")) {
                return 6;
            }
            if (linhaNormalizada.contains("Linha 4")) {
                return 3;
            }
            return 4;
        }

        if (tipo.equalsIgnoreCase("Trem")) {
            if (linhaNormalizada.contains("Linha 13")) {
                return 15;
            }
            if (linhaNormalizada.contains("Linha 7") || linhaNormalizada.contains("Linha 10") || linhaNormalizada.contains("Linha 11")) {
                return 8;
            }
            return 10;
        }

        return 0;
    }

    public static String montarTextoEstimativa(String tipoTransporte, String linha) {
        int minutos = calcularMinutos(tipoTransporte, linha);
        if (minutos <= 0) {
            return "Estimativa não disponível";
        }
        return "Aproximadamente " + minutos + " minutos";
    }
}
