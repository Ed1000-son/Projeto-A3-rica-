package a3;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

public class ExportadorDashboard {

    private ExportadorDashboard() {}

    public static void exportarCsv(Component parent) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Salvar dashboard para Excel");
        chooser.setSelectedFile(new File("dashboard_avaliacoes_transporte.csv"));
        chooser.setFileFilter(new FileNameExtensionFilter("Arquivo CSV compatível com Excel", "csv"));

        int escolha = chooser.showSaveDialog(parent);
        if (escolha != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File arquivo = chooser.getSelectedFile();
        if (!arquivo.getName().toLowerCase().endsWith(".csv")) {
            arquivo = new File(arquivo.getParentFile(), arquivo.getName() + ".csv");
        }

        try {
            String csv = AvaliacaoDAO.gerarCsvDashboard();
            // BOM UTF-8 para o Excel abrir acentos corretamente.
            try (FileOutputStream out = new FileOutputStream(arquivo)) {
                out.write(new byte[]{(byte)0xEF, (byte)0xBB, (byte)0xBF});
                out.write(csv.getBytes(StandardCharsets.UTF_8));
            }

            JOptionPane.showMessageDialog(
                    parent,
                    "Dashboard exportado com sucesso:\n" + arquivo.getAbsolutePath(),
                    "Exportação concluída",
                    JOptionPane.INFORMATION_MESSAGE
            );
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    parent,
                    "Não foi possível buscar os dados no banco.\n\nErro técnico: " + e.getMessage(),
                    "Erro ao exportar",
                    JOptionPane.ERROR_MESSAGE
            );
        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                    parent,
                    "Não foi possível salvar o arquivo.\n\nErro técnico: " + e.getMessage(),
                    "Erro ao salvar",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
