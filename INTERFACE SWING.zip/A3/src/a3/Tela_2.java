package a3;

import javax.swing.*;
import java.awt.*;

public class Tela_2 extends JFrame {
    private JTextArea comentarioArea;

    public Tela_2() {
        AppTheme.configureFrame(this, "Finalização - Pesquisa de Satisfação");

        JPanel root = AppTheme.root(7, "Finalização", "Deixe um comentário opcional e conclua a pesquisa.");
        JPanel card = AppTheme.card();
        GridBagConstraints gbc;

        JLabel icon = new JLabel("✅");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 44));
        icon.setHorizontalAlignment(SwingConstants.CENTER);
        gbc = AppTheme.gbc(0, 0);
        gbc.gridwidth = 2;
        card.add(icon, gbc);

        JLabel title = AppTheme.title("Obrigado pela participação");
        title.setHorizontalAlignment(SwingConstants.CENTER);
        gbc = AppTheme.gbc(0, 1);
        gbc.gridwidth = 2;
        card.add(title, gbc);

        JLabel subtitle = AppTheme.subtitle("Sua avaliação será usada para entender os pontos críticos da viagem e sugerir melhorias no serviço.");
        gbc = AppTheme.gbc(0, 2);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 8, 20, 8);
        card.add(subtitle, gbc);

        gbc = AppTheme.gbc(0, 3);
        gbc.gridwidth = 2;
        card.add(AppTheme.label("Comentário opcional"), gbc);

        comentarioArea = AppTheme.textArea();
        JScrollPane scroll = new JScrollPane(comentarioArea);
        scroll.setBorder(BorderFactory.createLineBorder(AppTheme.BORDER));
        gbc = AppTheme.gbc(0, 4);
        gbc.gridwidth = 2;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        card.add(scroll, gbc);

        JTextArea resumo = AppTheme.textArea();
        resumo.setEditable(false);
        resumo.setBackground(new Color(248, 250, 252));
        resumo.setText(montarResumo());
        JScrollPane resumoScroll = new JScrollPane(resumo);
        resumoScroll.setBorder(BorderFactory.createLineBorder(AppTheme.BORDER));
        gbc = AppTheme.gbc(0, 5);
        gbc.gridwidth = 2;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        card.add(resumoScroll, gbc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttons.setOpaque(false);
        JButton back = AppTheme.secondaryButton("Voltar");
        back.addActionListener(e -> { new Telaavaliacao().setVisible(true); dispose(); });
        JButton finish = AppTheme.primaryButton("Concluir");
        finish.addActionListener(e -> concluir());
        buttons.add(back);
        buttons.add(finish);

        gbc = AppTheme.gbc(0, 6);
        gbc.gridwidth = 2;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(18, 8, 8, 8);
        card.add(buttons, gbc);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private String montarResumo() {
        return "Resumo da avaliação\n" +
                "Nome: " + vazio(AppState.nome) + "\n" +
                "Transporte: " + vazio(AppState.tipoTransporte) + "\n" +
                "Linha: " + vazio(AppState.linha) + "\n" +
                "Estação: " + vazio(AppState.estacao) + "\n" +
                "Intervalo médio estimado: " + formatarIntervalo(AppState.intervaloMedioMinutos) + "\n" +
                "Data/Hora: " + vazio(AppState.data) + " " + vazio(AppState.hora) + "\n" +
                "Tempo de espera: " + AppState.espera + "/5\n" +
                "Lotação: " + AppState.lotacao + "/5\n" +
                "Qualidade geral: " + AppState.qualidade + "/5";
    }

    private String formatarIntervalo(int minutos) {
        return minutos > 0 ? minutos + " minutos" : "-";
    }

    private String vazio(String valor) {
        return valor == null || valor.isBlank() ? "-" : valor;
    }

    private void concluir() {
        AppState.comentario = comentarioArea.getText().trim();

        try {
            AvaliacaoDAO.salvarEstadoAtual();
            JOptionPane.showMessageDialog(
                    this,
                    "Pesquisa salva no banco de dados com sucesso!",
                    "Concluído",
                    JOptionPane.INFORMATION_MESSAGE
            );
            limparEstado();
            new Tela_1().setVisible(true);
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Não foi possível salvar no banco de dados.\n\n" +
                            "Confira se o MySQL está aberto, se o banco a3_transporte existe, " +
                            "se a tabela avaliacoes foi criada e se o Connector/J está no Classpath.\n\n" +
                            "Erro técnico: " + ex.getMessage(),
                    "Erro ao salvar",
                    JOptionPane.ERROR_MESSAGE
            );
            ex.printStackTrace();
        }
    }

    private void limparEstado() {
        AppState.nome = "";
        AppState.cpf = "";
        AppState.tipoTransporte = "";
        AppState.linha = "";
        AppState.estacao = "";
        AppState.intervaloMedioMinutos = -1;
        AppState.data = "";
        AppState.hora = "";
        AppState.espera = -1;
        AppState.lotacao = -1;
        AppState.qualidade = -1;
        AppState.comentario = "";
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Tela_2().setVisible(true));
    }
}
