package a3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class Telaadmin extends JFrame {
    private DefaultTableModel modelo;
    private JLabel resumoLabel;

    public Telaadmin() {
        AppTheme.configureFrame(this, "Admin - Dashboard");

        JPanel root = AppTheme.root(0, "Dashboard administrativo", "Área restrita para visualizar dados consolidados e exportar para Excel.");
        JPanel card = AppTheme.card();
        card.setLayout(new BorderLayout(14, 14));

        JPanel topo = new JPanel(new BorderLayout(10, 8));
        topo.setOpaque(false);

        JLabel title = AppTheme.title("Resumo das avaliações");
        JLabel subtitle = AppTheme.subtitle("Essa tela é somente para administrador. Aqui fica a exportação do dashboard.");
        resumoLabel = AppTheme.label("Carregando dados...");

        topo.add(title, BorderLayout.NORTH);
        topo.add(subtitle, BorderLayout.CENTER);
        topo.add(resumoLabel, BorderLayout.SOUTH);

        modelo = new DefaultTableModel(new Object[]{
                "Transporte", "Linha", "Estação", "Média intervalo", "Nota espera", "Lotação", "Qualidade", "Avaliações"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable tabela = new JTable(modelo);
        AppTheme.configureTable(tabela);
        JScrollPane scroll = new JScrollPane(tabela);
        scroll.getViewport().setBackground(Color.WHITE);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        botoes.setOpaque(false);

        JButton sair = AppTheme.secondaryButton("Sair do admin");
        sair.addActionListener(e -> { new Tela_1().setVisible(true); dispose(); });

        JButton atualizar = AppTheme.secondaryButton("Atualizar dados");
        atualizar.addActionListener(e -> carregarDados());

        JButton exportar = AppTheme.primaryButton("Exportar dashboard Excel");
        exportar.addActionListener(e -> ExportadorDashboard.exportarCsv(this));

        botoes.add(sair);
        botoes.add(atualizar);
        botoes.add(exportar);

        card.add(topo, BorderLayout.NORTH);
        card.add(scroll, BorderLayout.CENTER);
        card.add(botoes, BorderLayout.SOUTH);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
        carregarDados();
    }

    private void carregarDados() {
        modelo.setRowCount(0);
        try {
            List<AvaliacaoDAO.DashboardResumo> dados = AvaliacaoDAO.consultarResumoDashboard();
            if (dados.isEmpty()) {
                resumoLabel.setText("Nenhuma avaliação encontrada no banco.");
                return;
            }

            int total = 0;
            for (AvaliacaoDAO.DashboardResumo r : dados) {
                total += r.quantidadeAvaliacoes;
                modelo.addRow(new Object[]{
                        r.tipoTransporte,
                        r.linha,
                        r.estacao,
                        AvaliacaoDAO.formatarDecimal(r.mediaIntervalo) + " min",
                        AvaliacaoDAO.formatarDecimal(r.mediaEspera),
                        AvaliacaoDAO.formatarDecimal(r.mediaLotacao),
                        AvaliacaoDAO.formatarDecimal(r.mediaQualidade),
                        r.quantidadeAvaliacoes
                });
            }
            resumoLabel.setText("Total de avaliações usadas no dashboard: " + total);
        } catch (SQLException e) {
            resumoLabel.setText("Erro ao consultar o banco.");
            JOptionPane.showMessageDialog(
                    this,
                    "Não foi possível consultar o banco de dados.\n\nErro técnico: " + e.getMessage(),
                    "Erro no dashboard",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Telaadmin().setVisible(true));
    }
}
