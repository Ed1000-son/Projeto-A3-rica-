package a3;

import javax.swing.*;
import java.awt.*;

public class Telalocal extends JFrame {
    private JComboBox<String> tipoCombo;
    private JComboBox<String> linhaCombo;
    private JComboBox<String> estacaoCombo;

    public Telalocal() {
        AppTheme.configureFrame(this, "Local - Pesquisa de Satisfação");

        JPanel root = AppTheme.root(3, "Local da viagem", "Selecione o transporte, a linha e a estação utilizada.");
        JPanel card = AppTheme.card();
        GridBagConstraints gbc;

        JLabel title = AppTheme.title("Onde foi sua viagem?");
        gbc = AppTheme.gbc(0, 0);
        gbc.gridwidth = 2;
        card.add(title, gbc);

        JLabel subtitle = AppTheme.subtitle("As opções mudam automaticamente de acordo com o tipo de transporte escolhido.");
        gbc = AppTheme.gbc(0, 1);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 8, 20, 8);
        card.add(subtitle, gbc);

        gbc = AppTheme.gbc(0, 2);
        gbc.gridwidth = 1;
        card.add(AppTheme.label("Tipo de transporte"), gbc);
        tipoCombo = AppTheme.combo(new String[]{TransportData.SELECIONE, "Metrô", "Trem"});
        gbc = AppTheme.gbc(1, 2);
        gbc.weightx = 3;
        card.add(tipoCombo, gbc);

        gbc = AppTheme.gbc(0, 3);
        gbc.weightx = 1;
        card.add(AppTheme.label("Linha"), gbc);
        linhaCombo = AppTheme.combo(new String[]{TransportData.SELECIONE});
        gbc = AppTheme.gbc(1, 3);
        gbc.weightx = 3;
        card.add(linhaCombo, gbc);

        gbc = AppTheme.gbc(0, 4);
        gbc.weightx = 1;
        card.add(AppTheme.label("Estação"), gbc);
        estacaoCombo = AppTheme.combo(new String[]{TransportData.SELECIONE});
        gbc = AppTheme.gbc(1, 4);
        gbc.weightx = 3;
        card.add(estacaoCombo, gbc);

        tipoCombo.addActionListener(e -> atualizarLinhas());
        linhaCombo.addActionListener(e -> atualizarEstacoes());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttons.setOpaque(false);
        JButton back = AppTheme.secondaryButton("Voltar");
        back.addActionListener(e -> { new Telalogin().setVisible(true); dispose(); });
        JButton next = AppTheme.primaryButton("Continuar");
        next.addActionListener(e -> continuar());
        buttons.add(back);
        buttons.add(next);

        gbc = AppTheme.gbc(0, 5);
        gbc.gridwidth = 2;
        gbc.insets = new Insets(24, 8, 8, 8);
        card.add(buttons, gbc);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void atualizarLinhas() {
        String tipo = String.valueOf(tipoCombo.getSelectedItem());
        linhaCombo.removeAllItems();
        for (String item : TransportData.withDefault(TransportData.LINHAS_POR_TIPO.getOrDefault(tipo, new String[]{}))) linhaCombo.addItem(item);
        atualizarEstacoes();
    }

    private void atualizarEstacoes() {
        String linha = String.valueOf(linhaCombo.getSelectedItem());
        estacaoCombo.removeAllItems();
        for (String item : TransportData.withDefault(TransportData.ESTACOES_POR_LINHA.getOrDefault(linha, new String[]{}))) estacaoCombo.addItem(item);
    }

    private void continuar() {
        String tipo = String.valueOf(tipoCombo.getSelectedItem());
        String linha = String.valueOf(linhaCombo.getSelectedItem());
        String estacao = String.valueOf(estacaoCombo.getSelectedItem());
        if (TransportData.SELECIONE.equals(tipo) || TransportData.SELECIONE.equals(linha) || TransportData.SELECIONE.equals(estacao)) {
            AppTheme.showError(this, "Selecione transporte, linha e estação.");
            return;
        }
        AppState.tipoTransporte = tipo;
        AppState.linha = linha;
        AppState.estacao = estacao;
        new Telaintervalo().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Telalocal().setVisible(true));
    }
}
