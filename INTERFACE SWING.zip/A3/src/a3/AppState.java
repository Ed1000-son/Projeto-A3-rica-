package a3;

public final class AppState {
    public static String nome = "";
    public static String cpf = "";
    public static String tipoTransporte = "";
    public static String linha = "";
    public static String estacao = "";
    public static int intervaloMedioMinutos = -1;
    public static String data = "";
    public static String hora = "";
    public static int espera = -1;
    public static int lotacao = -1;
    public static int qualidade = -1;
    public static String comentario = "";

    private AppState() {}
}
