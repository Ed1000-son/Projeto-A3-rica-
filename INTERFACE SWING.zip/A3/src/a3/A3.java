package a3;

public class A3 {
    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Tela_1().setVisible(true));
    }
}
