package a3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexao {

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/a3_transporte";
    private static final String USUARIO = "root";
    private static final String SENHA = "@Texto1234";

    public static Connection conectar() throws SQLException {
        try {
            // Força o Java a carregar o driver do MySQL.
            // Se o mysql-connector-j não estiver no Classpath, o erro fica claro.
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException(
                    "Driver MySQL Connector/J não encontrado no projeto. "
                    + "Adicione o arquivo mysql-connector-j ao Libraries/Classpath do NetBeans.",
                    e
            );
        }

        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }
}
