package a3;

import javax.swing.*;
import java.awt.*;

public class Tela_1 extends JFrame {
    public Tela_1() {
        AppTheme.configureFrame(this, "Início - Pesquisa de Satisfação");

        JPanel root = AppTheme.root(1, "Início", "Pesquisa rápida para entender a experiência dos passageiros.");
        JPanel card = AppTheme.card();
        GridBagConstraints gbc;

        JLabel icon = new JLabel("🚇");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 56));
        icon.setHorizontalAlignment(SwingConstants.CENTER);
        gbc = AppTheme.gbc(0, 0);
        card.add(icon, gbc);

        JLabel title = AppTheme.title("Avalie sua viagem");
        title.setHorizontalAlignment(SwingConstants.CENTER);
        gbc = AppTheme.gbc(0, 1);
        card.add(title, gbc);

        JLabel subtitle = AppTheme.subtitle("Sua opinião ajuda a identificar problemas de espera, lotação, conforto e qualidade do serviço. O questionário é simples, direto e leva menos de um minuto.");
        subtitle.setHorizontalAlignment(SwingConstants.CENTER);
        gbc = AppTheme.gbc(0, 2);
        gbc.insets = new Insets(10, 8, 24, 8);
        card.add(subtitle, gbc);

        JButton start = AppTheme.primaryButton("Iniciar avaliação");
        start.addActionListener(e -> {
            new Telalogin().setVisible(true);
            dispose();
        });
        gbc = AppTheme.gbc(0, 3);
        gbc.fill = GridBagConstraints.NONE;
        card.add(start, gbc);

        JButton consulta = AppTheme.secondaryButton("Consulta rápida do trem");
        consulta.addActionListener(e -> {
            new Telaconsulta().setVisible(true);
            dispose();
        });
        gbc = AppTheme.gbc(0, 4);
        gbc.fill = GridBagConstraints.NONE;
        card.add(consulta, gbc);

        JButton admin = AppTheme.secondaryButton("Área do administrador");
        admin.addActionListener(e -> {
            new Telaadminlogin().setVisible(true);
            dispose();
        });
        gbc = AppTheme.gbc(0, 5);
        gbc.fill = GridBagConstraints.NONE;
        card.add(admin, gbc);

        JLabel observacao = AppTheme.subtitle("A consulta rápida não precisa de cadastro. A exportação de dashboard fica bloqueada na área do administrador.");
        observacao.setHorizontalAlignment(SwingConstants.CENTER);
        gbc = AppTheme.gbc(0, 6);
        gbc.insets = new Insets(16, 8, 8, 8);
        card.add(observacao, gbc);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    public static void main(String[] args) {
        AppTheme.setupLookAndFeel();
        java.awt.EventQueue.invokeLater(() -> new Tela_1().setVisible(true));
    }
}
