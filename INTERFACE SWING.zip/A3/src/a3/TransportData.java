package a3;

import java.util.LinkedHashMap;
import java.util.Map;

public final class TransportData {
    public static final String SELECIONE = "Selecione";

    public static final Map<String, String[]> LINHAS_POR_TIPO = new LinkedHashMap<>();
    public static final Map<String, String[]> ESTACOES_POR_LINHA = new LinkedHashMap<>();

    static {
        LINHAS_POR_TIPO.put("Metrô", new String[]{"Linha 1 - Azul", "Linha 2 - Verde", "Linha 3 - Vermelha", "Linha 4 - Amarela", "Linha 5 - Lilás", "Linha 15 - Prata", "Linha 17 - Ouro"});
        LINHAS_POR_TIPO.put("Trem", new String[]{"Linha 7 - Rubi", "Linha 8 - Diamante", "Linha 9 - Esmeralda", "Linha 10 - Turquesa", "Linha 11 - Coral", "Linha 12 - Safira", "Linha 13 - Jade"});

        ESTACOES_POR_LINHA.put("Linha 1 - Azul", new String[]{"Jabaquara", "Conceição", "São Judas", "Saúde", "Praça da Árvore", "Santa Cruz", "Vila Mariana", "Ana Rosa", "Paraíso", "Vergueiro", "São Joaquim", "Liberdade", "Sé", "São Bento", "Luz", "Tiradentes", "Armênia", "Portuguesa-Tietê", "Carandiru", "Santana", "Jardim São Paulo", "Parada Inglesa", "Tucuruvi"});
        ESTACOES_POR_LINHA.put("Linha 2 - Verde", new String[]{"Vila Prudente", "Tamanduateí", "Sacomã", "Alto do Ipiranga", "Santos-Imigrantes", "Chácara Klabin", "Ana Rosa", "Paraíso", "Brigadeiro", "Trianon-MASP", "Consolação", "Clínicas", "Sumaré", "Vila Madalena"});
        ESTACOES_POR_LINHA.put("Linha 3 - Vermelha", new String[]{"Corinthians-Itaquera", "Artur Alvim", "Patriarca", "Guilhermina-Esperança", "Vila Matilde", "Penha", "Carrão", "Tatuapé", "Belém", "Bresser-Mooca", "Brás", "Pedro II", "Sé", "Anhangabaú", "República", "Santa Cecília", "Marechal Deodoro", "Palmeiras-Barra Funda"});
        ESTACOES_POR_LINHA.put("Linha 4 - Amarela", new String[]{"Luz", "República", "Higienópolis-Mackenzie", "Paulista", "Oscar Freire", "Fradique Coutinho", "Faria Lima", "Pinheiros", "Butantã", "São Paulo-Morumbi", "Vila Sônia"});
        ESTACOES_POR_LINHA.put("Linha 5 - Lilás", new String[]{"Capão Redondo", "Campo Limpo", "Vila das Belezas", "Giovanni Gronchi", "Santo Amaro", "Largo Treze", "Adolfo Pinheiro", "Alto da Boa Vista", "Borba Gato", "Brooklin", "Campo Belo", "Eucaliptos", "Moema", "AACD-Servidor", "Hospital São Paulo", "Santa Cruz", "Chácara Klabin"});
        ESTACOES_POR_LINHA.put("Linha 15 - Prata", new String[]{"Vila Prudente", "Oratório", "São Lucas", "Camilo Haddad", "Vila Tolstói", "Vila União", "Jardim Planalto", "Sapopemba", "Fazenda da Juta", "São Mateus", "Jardim Colonial"});
        ESTACOES_POR_LINHA.put("Linha 17 - Ouro", new String[]{"Morumbi", "Vereador José Diniz", "Campo Belo", "Vila Cordeiro", "Chucri Zaidan", "Brooklin Paulista", "Washington Luís", "Aeroporto de Congonhas"});

        ESTACOES_POR_LINHA.put("Linha 7 - Rubi", new String[]{"Luz", "Palmeiras-Barra Funda", "Lapa", "Piqueri", "Pirituba", "Vila Clarice", "Jaraguá", "Vila Aurora", "Perus", "Caieiras", "Franco da Rocha", "Baltazar Fidélis", "Francisco Morato", "Botujuru", "Campo Limpo Paulista", "Várzea Paulista", "Jundiaí"});
        ESTACOES_POR_LINHA.put("Linha 8 - Diamante", new String[]{"Júlio Prestes", "Palmeiras-Barra Funda", "Lapa", "Domingos de Moraes", "Imperatriz Leopoldina", "Presidente Altino", "Osasco", "Comandante Sampaio", "Quitaúna", "General Miguel Costa", "Carapicuíba", "Santa Terezinha", "Antônio João", "Barueri", "Jardim Belval", "Jardim Silveira", "Jandira", "Sagrado Coração", "Engenheiro Cardoso", "Itapevi", "Amador Bueno"});
        ESTACOES_POR_LINHA.put("Linha 9 - Esmeralda", new String[]{"Osasco", "Presidente Altino", "Ceasa", "Villa-Lobos-Jaguaré", "Cidade Universitária", "Pinheiros", "Hebraica-Rebouças", "Cidade Jardim", "Vila Olímpia", "Berrini", "Morumbi", "Granja Julieta", "Santo Amaro", "Socorro", "Jurubatuba", "Autódromo", "Primavera-Interlagos", "Grajaú", "Mendes-Vila Natal"});
        ESTACOES_POR_LINHA.put("Linha 10 - Turquesa", new String[]{"Brás", "Juventus-Mooca", "Ipiranga", "Tamanduateí", "São Caetano", "Utinga", "Prefeito Saladino", "Santo André", "Prefeito Celso Daniel", "Capuava", "Mauá", "Guapituba", "Ribeirão Pires", "Rio Grande da Serra"});
        ESTACOES_POR_LINHA.put("Linha 11 - Coral", new String[]{"Luz", "Brás", "Tatuapé", "Corinthians-Itaquera", "Dom Bosco", "José Bonifácio", "Guaianases", "Antônio Gianetti Neto", "Ferraz de Vasconcelos", "Poá", "Calmon Viana", "Suzano", "Jundiapeba", "Braz Cubas", "Mogi das Cruzes", "Estudantes"});
        ESTACOES_POR_LINHA.put("Linha 12 - Safira", new String[]{"Brás", "Tatuapé", "Engenheiro Goulart", "USP Leste", "Comendador Ermelino", "São Miguel Paulista", "Jardim Helena-Vila Mara", "Itaim Paulista", "Jardim Romano", "Engenheiro Manoel Feio", "Itaquaquecetuba", "Aracaré", "Calmon Viana"});
        ESTACOES_POR_LINHA.put("Linha 13 - Jade", new String[]{"Engenheiro Goulart", "Guarulhos-Cecap", "Aeroporto-Guarulhos"});
    }

    public static String[] withDefault(String[] values) {
        String[] result = new String[values.length + 1];
        result[0] = SELECIONE;
        System.arraycopy(values, 0, result, 1, values.length);
        return result;
    }

    private TransportData() {}
}
