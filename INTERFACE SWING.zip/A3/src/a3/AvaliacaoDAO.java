package a3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class AvaliacaoDAO {

    private static final DateTimeFormatter DATA_BR = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter HORA_BR = DateTimeFormatter.ofPattern("HH:mm");

    public static class ConsultaIntervalo {
        public final String tipoTransporte;
        public final String linha;
        public final String estacao;
        public final double mediaIntervalo;
        public final int quantidadeAvaliacoes;
        public final String ultimaAvaliacao;

        public ConsultaIntervalo(String tipoTransporte, String linha, String estacao, double mediaIntervalo, int quantidadeAvaliacoes, String ultimaAvaliacao) {
            this.tipoTransporte = tipoTransporte;
            this.linha = linha;
            this.estacao = estacao;
            this.mediaIntervalo = mediaIntervalo;
            this.quantidadeAvaliacoes = quantidadeAvaliacoes;
            this.ultimaAvaliacao = ultimaAvaliacao;
        }
    }

    public static class DashboardResumo {
        public final String tipoTransporte;
        public final String linha;
        public final String estacao;
        public final double mediaIntervalo;
        public final double mediaEspera;
        public final double mediaLotacao;
        public final double mediaQualidade;
        public final int quantidadeAvaliacoes;

        public DashboardResumo(String tipoTransporte, String linha, String estacao, double mediaIntervalo, double mediaEspera, double mediaLotacao, double mediaQualidade, int quantidadeAvaliacoes) {
            this.tipoTransporte = tipoTransporte;
            this.linha = linha;
            this.estacao = estacao;
            this.mediaIntervalo = mediaIntervalo;
            this.mediaEspera = mediaEspera;
            this.mediaLotacao = mediaLotacao;
            this.mediaQualidade = mediaQualidade;
            this.quantidadeAvaliacoes = quantidadeAvaliacoes;
        }
    }

    public static void salvarAvaliacao(
            String nome,
            String cpf,
            String tipoTransporte,
            String linha,
            String estacao,
            String dataViagem,
            String horaViagem,
            int intervaloMedioMinutos,
            int notaEspera,
            int notaLotacao,
            int notaQualidade,
            String comentario
    ) throws SQLException {

        String sql = """
            INSERT INTO avaliacoes (
                nome,
                cpf,
                tipo_transporte,
                linha,
                estacao,
                data_viagem,
                hora_viagem,
                intervalo_medio_minutos,
                nota_espera,
                nota_lotacao,
                nota_qualidade,
                comentario
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, limparTexto(nome));
            stmt.setString(2, limparTexto(cpf));
            stmt.setString(3, limparTexto(tipoTransporte));
            stmt.setString(4, limparTexto(linha));
            stmt.setString(5, limparTexto(estacao));
            stmt.setDate(6, Date.valueOf(converterData(dataViagem)));
            stmt.setTime(7, Time.valueOf(converterHora(horaViagem)));
            stmt.setInt(8, intervaloMedioMinutos);
            stmt.setInt(9, notaEspera);
            stmt.setInt(10, notaLotacao);
            stmt.setInt(11, notaQualidade);
            stmt.setString(12, limparTexto(comentario));

            stmt.executeUpdate();
        }
    }

    public static void salvarEstadoAtual() throws SQLException {
        salvarAvaliacao(
                AppState.nome,
                AppState.cpf,
                AppState.tipoTransporte,
                AppState.linha,
                AppState.estacao,
                AppState.data,
                AppState.hora,
                AppState.intervaloMedioMinutos,
                AppState.espera,
                AppState.lotacao,
                AppState.qualidade,
                AppState.comentario
        );
    }

    public static List<ConsultaIntervalo> consultarIntervaloTremUltimaHora() throws SQLException {
        String filtroTrem = """
            (
                LOWER(tipo_transporte) LIKE '%trem%'
                OR LOWER(linha) LIKE '%rubi%'
                OR LOWER(linha) LIKE '%diamante%'
                OR LOWER(linha) LIKE '%esmeralda%'
                OR LOWER(linha) LIKE '%turquesa%'
                OR LOWER(linha) LIKE '%coral%'
                OR LOWER(linha) LIKE '%safira%'
                OR LOWER(linha) LIKE '%jade%'
            )
        """;

        String sqlUltimaHoraComCriadoEm = """
            SELECT
                tipo_transporte,
                linha,
                estacao,
                AVG(intervalo_medio_minutos) AS media_intervalo,
                COUNT(*) AS quantidade,
                MAX(criado_em) AS ultima_avaliacao
            FROM avaliacoes
            WHERE %s
              AND intervalo_medio_minutos IS NOT NULL
              AND intervalo_medio_minutos > 0
              AND criado_em >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            GROUP BY tipo_transporte, linha, estacao
            ORDER BY media_intervalo DESC, quantidade DESC, linha, estacao
        """.formatted(filtroTrem);

        String sqlUltimaHoraSemCriadoEm = """
            SELECT
                tipo_transporte,
                linha,
                estacao,
                AVG(intervalo_medio_minutos) AS media_intervalo,
                COUNT(*) AS quantidade,
                MAX(TIMESTAMP(data_viagem, hora_viagem)) AS ultima_avaliacao
            FROM avaliacoes
            WHERE %s
              AND intervalo_medio_minutos IS NOT NULL
              AND intervalo_medio_minutos > 0
              AND TIMESTAMP(data_viagem, hora_viagem) >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            GROUP BY tipo_transporte, linha, estacao
            ORDER BY media_intervalo DESC, quantidade DESC, linha, estacao
        """.formatted(filtroTrem);

        String sqlTodosComCriadoEm = """
            SELECT
                tipo_transporte,
                linha,
                estacao,
                AVG(intervalo_medio_minutos) AS media_intervalo,
                COUNT(*) AS quantidade,
                MAX(criado_em) AS ultima_avaliacao
            FROM avaliacoes
            WHERE %s
              AND intervalo_medio_minutos IS NOT NULL
              AND intervalo_medio_minutos > 0
            GROUP BY tipo_transporte, linha, estacao
            ORDER BY ultima_avaliacao DESC, media_intervalo DESC, quantidade DESC, linha, estacao
        """.formatted(filtroTrem);

        String sqlTodosSemCriadoEm = """
            SELECT
                tipo_transporte,
                linha,
                estacao,
                AVG(intervalo_medio_minutos) AS media_intervalo,
                COUNT(*) AS quantidade,
                MAX(TIMESTAMP(data_viagem, hora_viagem)) AS ultima_avaliacao
            FROM avaliacoes
            WHERE %s
              AND intervalo_medio_minutos IS NOT NULL
              AND intervalo_medio_minutos > 0
            GROUP BY tipo_transporte, linha, estacao
            ORDER BY ultima_avaliacao DESC, media_intervalo DESC, quantidade DESC, linha, estacao
        """.formatted(filtroTrem);

        try {
            List<ConsultaIntervalo> ultimaHora = executarConsultaIntervalo(sqlUltimaHoraComCriadoEm);
            if (!ultimaHora.isEmpty()) {
                return ultimaHora;
            }
            return executarConsultaIntervalo(sqlTodosComCriadoEm);
        } catch (SQLSyntaxErrorException e) {
            List<ConsultaIntervalo> ultimaHora = executarConsultaIntervalo(sqlUltimaHoraSemCriadoEm);
            if (!ultimaHora.isEmpty()) {
                return ultimaHora;
            }
            return executarConsultaIntervalo(sqlTodosSemCriadoEm);
        }
    }

    public static List<DashboardResumo> consultarResumoDashboard() throws SQLException {
        String sql = """
            SELECT
                tipo_transporte,
                linha,
                estacao,
                AVG(intervalo_medio_minutos) AS media_intervalo,
                AVG(nota_espera) AS media_espera,
                AVG(nota_lotacao) AS media_lotacao,
                AVG(nota_qualidade) AS media_qualidade,
                COUNT(*) AS quantidade
            FROM avaliacoes
            GROUP BY tipo_transporte, linha, estacao
            ORDER BY tipo_transporte, linha, estacao
        """;

        List<DashboardResumo> lista = new ArrayList<>();
        try (Connection conn = conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(new DashboardResumo(
                        rs.getString("tipo_transporte"),
                        rs.getString("linha"),
                        rs.getString("estacao"),
                        rs.getDouble("media_intervalo"),
                        rs.getDouble("media_espera"),
                        rs.getDouble("media_lotacao"),
                        rs.getDouble("media_qualidade"),
                        rs.getInt("quantidade")
                ));
            }
        }
        return lista;
    }

    public static String gerarCsvDashboard() throws SQLException {
        List<DashboardResumo> dados = consultarResumoDashboard();
        StringBuilder sb = new StringBuilder();
        sb.append("Dashboard de avaliacoes de transporte\n");
        sb.append("Gerado em;").append(java.time.LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))).append("\n\n");
        sb.append("Transporte;Linha;Estacao;Media intervalo minutos;Media nota espera;Media nota lotacao;Media nota qualidade;Quantidade avaliacoes\n");
        for (DashboardResumo r : dados) {
            sb.append(csv(r.tipoTransporte)).append(';')
              .append(csv(r.linha)).append(';')
              .append(csv(r.estacao)).append(';')
              .append(formatarDecimal(r.mediaIntervalo)).append(';')
              .append(formatarDecimal(r.mediaEspera)).append(';')
              .append(formatarDecimal(r.mediaLotacao)).append(';')
              .append(formatarDecimal(r.mediaQualidade)).append(';')
              .append(r.quantidadeAvaliacoes).append('\n');
        }
        return sb.toString();
    }

    private static List<ConsultaIntervalo> executarConsultaIntervalo(String sql) throws SQLException {
        List<ConsultaIntervalo> lista = new ArrayList<>();
        try (Connection conn = conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(new ConsultaIntervalo(
                        rs.getString("tipo_transporte"),
                        rs.getString("linha"),
                        rs.getString("estacao"),
                        rs.getDouble("media_intervalo"),
                        rs.getInt("quantidade"),
                        rs.getString("ultima_avaliacao")
                ));
            }
        }
        return lista;
    }

    private static String csv(String valor) {
        if (valor == null) return "";
        String limpo = valor.replace("\"", "\"\"");
        if (limpo.contains(";") || limpo.contains("\n") || limpo.contains("\"")) {
            return "\"" + limpo + "\"";
        }
        return limpo;
    }

    public static String formatarDecimal(double valor) {
        return String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.1f", valor);
    }

    private static String limparTexto(String valor) {
        return valor == null ? "" : valor.trim();
    }

    private static LocalDate converterData(String data) throws SQLException {
        try {
            return LocalDate.parse(limparTexto(data), DATA_BR);
        } catch (DateTimeParseException e) {
            throw new SQLException("Data inválida. Use o formato dd/mm/aaaa.", e);
        }
    }

    private static LocalTime converterHora(String hora) throws SQLException {
        try {
            return LocalTime.parse(limparTexto(hora), HORA_BR);
        } catch (DateTimeParseException e) {
            throw new SQLException("Hora inválida. Use o formato hh:mm.", e);
        }
    }
}
