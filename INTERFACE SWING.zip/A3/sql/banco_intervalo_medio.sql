-- Execute este script no MySQL antes de testar a consulta/exportação.
-- Banco usado pelo Java: a3_transporte

CREATE DATABASE IF NOT EXISTS a3_transporte;
USE a3_transporte;

-- Caso a tabela ainda não exista, esta estrutura funciona com o código Java do projeto.
CREATE TABLE IF NOT EXISTS avaliacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    cpf VARCHAR(20) NOT NULL,
    tipo_transporte VARCHAR(50) NOT NULL,
    linha VARCHAR(120) NOT NULL,
    estacao VARCHAR(120) NOT NULL,
    data_viagem DATE NOT NULL,
    hora_viagem TIME NOT NULL,
    intervalo_medio_minutos INT NULL,
    nota_espera INT NOT NULL,
    nota_lotacao INT NOT NULL,
    nota_qualidade INT NOT NULL,
    comentario TEXT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Se a tabela já existia antes, rode estes ALTERs.
-- Se aparecer erro dizendo que a coluna já existe, ignore esse ALTER específico.
ALTER TABLE avaliacoes
ADD COLUMN intervalo_medio_minutos INT NULL AFTER hora_viagem;

ALTER TABLE avaliacoes
ADD COLUMN criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER comentario;

-- Consulta usada pela tela "Consulta rápida do trem":
SELECT
    tipo_transporte,
    linha,
    estacao,
    AVG(intervalo_medio_minutos) AS media_intervalo_minutos,
    COUNT(*) AS quantidade_avaliacoes,
    MAX(criado_em) AS ultima_avaliacao
FROM avaliacoes
WHERE tipo_transporte LIKE '%Trem%'
  AND intervalo_medio_minutos IS NOT NULL
  AND criado_em >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
GROUP BY tipo_transporte, linha, estacao
ORDER BY media_intervalo_minutos DESC;

-- Consulta base do dashboard exportado para Excel/CSV:
SELECT
    tipo_transporte,
    linha,
    estacao,
    AVG(intervalo_medio_minutos) AS media_intervalo_minutos,
    AVG(nota_espera) AS media_nota_espera,
    AVG(nota_lotacao) AS media_nota_lotacao,
    AVG(nota_qualidade) AS media_nota_qualidade,
    COUNT(*) AS quantidade_avaliacoes
FROM avaliacoes
GROUP BY tipo_transporte, linha, estacao
ORDER BY tipo_transporte, linha, estacao;
